﻿using System;

namespace ReplaceChar
{
    class Program
    {
        
        static void Main(string[] args)
        {
            string str1,str2;
            
            int l=0, i;
            char ch;
            Console.Write("\n Replace Lower case.by uppercase\n");
            Console.Write("-----------------------------------------------\n");
            Console.Write("Input the string:");
            str1 = Console.ReadLine();
            Console.WriteLine(str1.ToUpper());
        }
    }
}
