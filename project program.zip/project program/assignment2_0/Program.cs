﻿using System;

namespace assignment2_0
{
    class Program
    {
        static void Main(string[] args)
        {
            double chargeAmt, surchargeAmt = 0, grandT, total;
            string cusName;
            int meterId, unit;

            Console.WriteLine("\n\n");
            Console.WriteLine("Generating Electricity Bill:\n\n");
            Console.WriteLine("=================================\n\n");
            Console.WriteLine("\n\n");
            Console.WriteLine("Enter meter Id:");
            meterId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Customer Name:");
            cusName = Console.ReadLine();
            Console.WriteLine("Enter the amount of unit consume:");
            unit = Convert.ToInt32(Console.ReadLine());

            if (unit <= 1000)
                chargeAmt = 7;
            else if (unit >= 500 && unit < 1000)
                chargeAmt = 6;
            else if (unit >= 300 && unit < 500)
                chargeAmt = 5;
            else if (unit >= 200 && unit < 300)
                chargeAmt = 3;
            else
                chargeAmt = 7;
            grandT = unit * chargeAmt;

            if(grandT > 300)
            
                surchargeAmt = grandT * 7.5 / 100;
                total = grandT + surchargeAmt;
                if( total < 100)
                
                    total = 100;

            Console.Write("\n ELECTROCITY BILL\n");
            Console.Write(" meter Id : {0}\n",meterId);
            Console.Write(" Customer Name : {0}\n", cusName);
            Console.Write(" Unit Consumed : {0}\n", unit);
            Console.Write(" Amount Charge@USD{0}per unit : {1}\n", chargeAmt,grandT);
            Console.Write(" SurCharge Amount: {0}\n",surchargeAmt);
            Console.Write(" Net Amount Paid by Customer : {0}\n", total);

            Console.ReadKey();

        }
    }
}
