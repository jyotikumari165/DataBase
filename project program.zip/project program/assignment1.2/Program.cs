﻿using System;

namespace assignment1._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter your roll no");
            string roll = Console.ReadLine();
            Console.WriteLine("Enter your class");
            string standard = Console.ReadLine();
            Console.WriteLine("Enter Math Marks");
            int m = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter English Marks");
            int e = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Hindi Marks");
            int h = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Punjabi Marks");
            int p = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Science Marks");
            int sci = int.Parse(Console.ReadLine());

            int obt = m + e + h + p + sci;
            int per = obt * 100 / 500;
            Console.WriteLine("---------------MARKSHEET----------------");

            Console.WriteLine(" your Name is: {0}",name);
            Console.WriteLine(" your Roll no is:{0}",roll);
            Console.WriteLine("your class is:{0}",standard);
            Console.WriteLine("your Obtained Marks are:{0}",obt);
            Console.WriteLine("your Percentage is:{0}",per);

            if(per >= 80)
            {
                Console.WriteLine("Grade: A+");

            }
            else if(per >= 70)
            {
                Console.WriteLine("Grade: A");
            }
            else if(per >= 60)
            {
                Console.WriteLine("Grade: B");
            }
            else if(per >= 50)
            {
                Console.WriteLine("Grade: C");
            }
            else if(per >=40)
            {
                Console.WriteLine("Grade: D");
            }
            else if(per >= 33)
            {
                Console.WriteLine("Grade: E ");

            }
            else
            {
                Console.WriteLine("Grade: Fail");
            }
            //if else for Reamrks

            if (per >= 80)
            {
                Console.WriteLine("Remaks: Excellent !!");

            }
            else if (per >= 70)
            {
                Console.WriteLine("Remarks: Very Good");
            }
            else if (per >= 60)
            {
                Console.WriteLine("Remarks: Good");
            }
            else if (per >= 50)
            {
                Console.WriteLine("Remarks: Fair");
            }
            else if (per >= 40)
            {
                Console.WriteLine("Grade: Poor");
            }
            else if (per >= 33)
            {
                Console.WriteLine("Remarks:Needs a lot of improvement");

            }
            else
            {
                Console.WriteLine("Remarks: Bring your parents tomarrow");
            }
            Console.ReadLine();
        }
    }
}
