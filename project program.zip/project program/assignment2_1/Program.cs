﻿using System;

namespace assignment2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            Console.WriteLine("Enter the number to check Prime");
            int num = int.Parse(Console.ReadLine());

            for(int i = 1; i <= num; i++)
            {
                if(num % i == 0)
                {
                     count++;
                }
            }
            if( count == 2)
            {
                Console.WriteLine("prime number");
            }
            else
            {
                Console.WriteLine("Not a prime number");
            }
            Console.ReadLine();
        }
       
    }
}
