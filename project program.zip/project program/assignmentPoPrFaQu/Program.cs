﻿using System;

namespace assignmentPoPrFaQu
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the value:");
            int num = int.Parse(Console.ReadLine());
            int count = 0,fact=0,cube;

            if(num>0)
            {

                if (CheckPrime == true)
                {
                    for (int i = num - 1; i >= 1; i--)
                    {

                        fact = fact * i;
                        fact = num;
                    }
                    Console.WriteLine(fact);
                }
                 
                else
                {
                    cube= num* num * num;
                    Console.WriteLine( " " + cube + "this is a cube!");
                }
            }
            else
            {
                Console.WriteLine("Please enter the positive number");
            }
            Console.ReadKey();
        }

        public static bool CheckPrime()
        {
            bool num1;
            int fact = 0;


            for (int i=2;i<=Num1;i++)
            {
                fact = num1;
                if (num1 % i == 0)
                {
                    count++;
                }
                else if (count == 2)
                {
                    return true;
                }
                else
                    return false;
            }

        }
    }
}
