﻿using System;

namespace assignment1._1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, n3, largest;
            Console.WriteLine("Enter the number for n1:");
            n1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the number for n2:");
            n2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the number for n3:");
            n3 = Convert.ToInt32(Console.ReadLine());

            if (n1 > n2 && n1 > n3)
                largest = n1;
            else if (n2 > n1 && n2 > n3)
                largest = n2;
            else
                largest = n3;

            Console.WriteLine("Largest among {0},{1} and {2} is {3}", n1, n2, n3, largest);
            Console.WriteLine("Press any key to exist");
            Console.ReadKey();
        }
    }
}
