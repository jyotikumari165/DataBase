﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Project_Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Load();

        }
        SqlConnection con = new SqlConnection(@"Data Source=localhost;Initial Catalog=gcbt;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader read;
        SqlDataAdapter drr;
        bool Mode = true;
        string sql;


        public void Load()
        {
            try
            {
                sql = "select * from student_table";
                cmd = new SqlCommand(sql, con);
                con.Open();
                read = cmd.ExecuteReader();
                drr = new SqlDataAdapter(sql, con);
                dataGridView1.Rows.Clear();

                while(read.Read())
                {
                    dataGridView1.Rows.Add(read[0], read[1], read[2], read[3]);

                }
                con.Close();

            }
            catch(Exception ex)
            {
                MessageBox.Show("ex.message");
            }
        }









        private void textBox1_TextChanged(object sender, EventArgs e)
        { 
          
               
         }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string course = txtCourse.Text;
            string fee = txtFee.Text;
            
            
                if (Mode == true)
                {
                    sql = "insert into student_table(Stuname,Course,fee) values($Stuname,$Course,$fee)";
                    con.Open();
                    cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("$stuname", name);
                    cmd.Parameters.AddWithValue("$Course", course);
                    cmd.Parameters.AddWithValue("$fee", fee);

                    MessageBox.Show("Record added");
                    //cmd.ExecuteNonQuery();

                txtName.Clear();
                txtCourse.Clear();
                txtFee.Clear();
                txtName.Focus();

            }
                else
                {
                 

                }
            con.Close();
        }
    }
}
