﻿using System;

namespace assignment2_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string myStr;
            int i, vowel_count, len;
            Console.WriteLine("Enter the String");
             myStr = Console.ReadLine();
            
            vowel_count = 0;
           

            len = myStr.Length;

            for( i = 0; i <=len; i++)
            {

                  if(myStr[i]=='A'||myStr[i]=='E'||myStr[i]=='I'||myStr[i]=='O'||myStr[i]=='U')
                {
                    vowel_count++;
                }
                else
                {
                    Console.WriteLine(" No any vowel in this words")
                }
            }

            Console.WriteLine("\n Vowels in the string:{0}", vowel_count[i]);
            Console.ReadKey();
        }
       
    }
   
   
}
