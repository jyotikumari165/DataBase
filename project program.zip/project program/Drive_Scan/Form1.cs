﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Drive_Scan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            //  var drives = DriveInfo.GetDrives();
            //foreach (var drive in drives)
            string fileName = @"C:\mydir\myfile.ext";
            string path = @"C:\mydir\";
            string result;
            result = Path.GetFileName(path);

            FileInfo f = new FileInfo(path);
            string drive = Path.GetPathRoot(f.FullName);


            //var files = System.IO.Directory.GetFiles(cbmExtn.Text, "*.*",
              //System.IO.SearchOption.AllDirectories);

            listfiles.DataSource = files;
            MessageBox.Show(files.Count() + "files found");
                   
                
   
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            



        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {


            foreach (var drive in DriveInfo.GetDrives())
            {
                if(drive.DriveType == DriveType.Fixed)
                {
                    cbmExtn.Items.Add(drive.RootDirectory);
                }
            }
           

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            dlg.ShowDialog();
            txtDirectory.Text = dlg.SelectedPath;

        }

        private void button2_Click(object sender, EventArgs e)
        {
           var files = System.IO.Directory.GetFiles(txtDirectory.Text,
                "*.*", System.IO.SearchOption.AllDirectories);

            lstFiles.DataSource = files;
            MessageBox.Show(files.Count() + "files found")
        }
    }
}
