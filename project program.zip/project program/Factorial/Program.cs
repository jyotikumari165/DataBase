﻿using System;

namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int fact = 0;
            Console.WriteLine("Enter the value:");
            int num = int.Parse(Console.ReadLine());
            fact = num;
            for (int i = num - 1; i >= 1; i--)
            {
                fact = fact * i;

            }
            Console.WriteLine(fact);
        }
    }
}
